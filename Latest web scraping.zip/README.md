# webscraping
Scraping websites for tracking information

python -m venv scraping_env
pip install -r requirements.txt